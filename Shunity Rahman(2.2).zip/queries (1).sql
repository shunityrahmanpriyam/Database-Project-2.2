CREATE TABLE Agent (
    Agent_ID INT PRIMARY KEY,
    A_Name VARCHAR(255) NOT NULL,
    A_Contact_Info VARCHAR(255),
    Agency VARCHAR(100)
);

CREATE TABLE Customer (
    Customer_ID INT PRIMARY KEY,
    C_Name VARCHAR(255) NOT NULL,
    C_Contact_Info VARCHAR(255),
    C_Type VARCHAR(50)
);

CREATE TABLE Location (
    Location_ID INT PRIMARY KEY,
    L_Address VARCHAR(255),
    Zip VARCHAR(100),
    City VARCHAR(100)

);
CREATE TABLE Property(
    Property_ID INT PRIMARY KEY,
    P_Address VARCHAR(255) NOT NULL,
    P_Price DECIMAL(10, 2),
    P_Size VARCHAR(255),
    P_Type VARCHAR(50),
    P_Status VARCHAR(20),
    Location_ID INT,
    Agent_ID INT,
    FOREIGN KEY (Location_ID) REFERENCES Location(Location_ID),
    FOREIGN KEY (Agent_ID) REFERENCES Agent(Agent_ID)
);


CREATE TABLE Property_Features(
    Feature_ID INT PRIMARY KEY,
    Property_ID INT,
    Feature_Type VARCHAR(100),
    Feature_Description TEXT,
    FOREIGN KEY (Property_ID) REFERENCES Property(Property_ID)
);

CREATE TABLE Transaction_Type (
    Transaction_Type_ID INT PRIMARY KEY,
    t_Type VARCHAR(255),
    t_Description VARCHAR(100)

);

CREATE TABLE Transaction (
    Transaction_ID INT PRIMARY KEY,
    Property_ID INT,
    Buyer_ID INT,
    Seller_ID INT,
    Agent_ID INT,
    T_Date DATE,
    T_Price DECIMAL(10, 2),
    Transaction_Type_ID INT,
    FOREIGN KEY (Property_ID) REFERENCES Property(Property_ID),
    FOREIGN KEY (Buyer_ID) REFERENCES Customer(Customer_ID),
    FOREIGN KEY (Seller_ID) REFERENCES Customer(Customer_ID),
    FOREIGN KEY (Agent_ID) REFERENCES Agent(Agent_ID),
    FOREIGN KEY (Transaction_Type_ID) REFERENCES Transaction_Type(Transaction_Type_ID)
);

CREATE TABLE Investor(
    Investor_ID int primary key,
    I_name varchar(50) not null,
    I_Contact_Info varchar(20),
    I_address varchar(50),
    Investment_focus varchar(30),
    I_budget decimal(10,2),
    Property_ID INT,
    Location_ID INT,
    FOREIGN KEY (Property_ID) REFERENCES Property(Property_ID),
    FOREIGN KEY (Location_ID) REFERENCES Location(Location_ID)
  
);


CREATE TABLE Developer(
    Developer_ID int primary key,
    D_name varchar(50) not null,
    D_company_name varchar(50) not null,
    D_Contact_Info varchar(20),
    D_address varchar(50),
    D_rating decimal(3,2),
    Property_ID INT,
    Location_ID INT,
    FOREIGN KEY (Property_ID) REFERENCES Property(Property_ID),
    FOREIGN KEY (Location_ID) REFERENCES Location(Location_ID)

);


INSERT INTO Agent(Agent_ID,A_Name,A_Contact_Info, Agency) 

 VALUES
  (10, 'Sanjida', '+8801869509177', 'UAP Agency'),
  (70, 'Polok', '+8801869503337', 'AB Agency'),
  (40, 'Jamal', '+8801862417632', 'BCD Agency'),
  (20, 'Tarif', '+8801741528652', 'AR Agency'),
  (50, 'Kamal', '+8802103017775', 'SK Agency'),
  (30, 'Mou', '+8801741527896', 'TB Agency'),
  (65, 'Mahbub', '+8801321456987', 'MB Agency'),
  (75, 'Rita', '+8801417412585', 'DD Agency'),
  (85, 'Mita', '+8801749331448', 'TY Agency'),
  (95, 'Mina', '+8801869502222', 'OP Agency');
 
SELECT * FROM Agent;

INSERT INTO Customer(Customer_ID,C_Name,C_Contact_Info, C_Type) 

 VALUES
  (101, 'Rahman', '+8801774127988', 'Buyer'),
  (102, 'Mahmud', '+8801869509172', 'Seller'),
  (103, 'Moumita', '+8801869509111', 'Renter'),
  (104, 'Tamim', '+8801869509166', 'Buyer'),
  (105, 'Hosain', '+8801869509190', 'Seller'),
  (106, 'Helal', '+8801869509190', 'Buyer'),
  (107, 'Hosain', '+8801869509190', 'Seller'),
  (108, 'Tamim', '+8801869509190', 'Renter'),
  (109, 'Hasan', '+8801869509190', 'Buyer');
 
SELECT * FROM Customer;

INSERT INTO Location(Location_ID,L_Address,Zip, City) 

 VALUES
  (400, 'House 1, Road 8, Uttara','1230', 'Dhaka'),
  (401, 'House 12, Road 5, Green road','1235', 'Dhaka'),
  (402,'House 23, Road 3, Khilgaon','1234', 'Dhaka'),
  (403, 'House 4, Road 10, Mouchak','1231', 'Dhaka'),
  (404, 'House 4, Road 6, Bonosree','1238', 'Dhaka'),
  (405, 'House 7, Road 19, Uttara','1230', 'Dhaka'),
  (406, 'House 8, Road 6, Bonosree','1238', 'Dhaka'),
  (407, 'House 4, Road 5, Mouchak','1231', 'Dhaka'),
  (408, 'House 17, Road 3, Mirpur-1','1231', 'Dhaka'),
  (409, 'House 27, Road 7, Bonosree','1238', 'Dhaka'),
  (410, 'House 23, Road 6, Khilgaon','1234', 'Dhaka');


SELECT * FROM Location;

INSERT INTO Property(Property_ID,P_Address,P_Price,P_Size,P_Type,P_Status,Location_ID, Agent_ID) 

 VALUES
  (1, 'Green Road', 25000000, '3.22acres', 'Residential', 'Sale', 401, 10),
  (2, 'Khilgaon', 50000, '0.4acres', 'Residential', 'rented', 402, 20),
  (3, 'Uttora', 25000000, '3.22acres', 'Residential', 'Sale', 405, 30),
  (4, 'Mouchak', 25000000, '3.22acres', 'Residential', 'Sale',403, 10),
  (5, 'Bonosree', 25000000, '2.28acres', 'Commercial', 'Sold', 406, 50),
  (6, 'Mirpur-1', 12300000, '2.72acres', 'Residential', 'Sold', 408, 65),
  (7, 'Bonosree', 26500000, '3.50acres', 'Commercial', 'Sale',404, 75),
  (8, 'Khilgaon', 24000000, '3.44acres', 'Residential', 'Sold',410, 85),
  (9, 'Bonosree', 45000000, '4.22acres', 'Commercial', 'Sale',409, 20),
  (10, 'Uttora', 25500, '3.22acres', 'Residential', 'rented',400, 50);
 
SELECT * FROM Property;

INSERT INTO Property_Features(Feature_ID,Property_ID,Feature_Type, Feature_Description) 

 VALUES
  (300, 1, 'Flat', 'The flat is 1400 square feet.'),
  (301, 2, 'Garage', 'The Garage is 600 square feet.'),
  (302, 3, 'flat', 'The flat is 1400 square feet.'),
  (303, 5, 'flat', 'The flat is 1800 square feet.'),
  (304, 4, 'Pool', 'The pool is 40 and 80 square feet and a 2:1 rectangle.'),
  (305, 9, 'flat', 'The flat is 1400 square feet.'),
  (306, 7, 'flat', 'The flat is 1900 square feet.'),
  (307, 10, 'flat', 'The flat is 1400 square feet.'),
  (308, 6, 'flat', 'The flat is 1700 square feet.'),
  (309, 8, 'flat', 'The flat is 2400 square feet.');
 
SELECT * FROM Property_Features;

INSERT INTO Transaction_Type(Transaction_Type_ID,t_Type,t_Description) 

 VALUES
  (500,'sell', 'Sells order issue'),
  (501, 'rent', 'rented order issue'),
  (502, 'sell', 'Sells order issue'),
  (503, 'sell', 'Sells order issue'),
  (504,'sold', 'Purchase order issue'),
  (505, 'sell', 'Sells order issue'),
  (506, 'sell', 'Sells order issue'),
  (507, 'rent', 'rented order issue'),
  (508,'sold', 'Purchase order issue'),
  (509,'sold', 'Purchase order issue');
 
SELECT * FROM Transaction_Type;

INSERT INTO Transaction(Transaction_ID,Property_ID,Buyer_ID,Seller_ID,Agent_ID,T_date, T_Price,Transaction_Type_ID) 

 VALUES
  (1001,1,101,105,10, '2023-01-01',25000000,500),
  (1002,6,104,102,20,'2023-11-15',12300000,509),
  (1003, 3,106,107,20, '2023-05-10',25000000,502),
  (1004, 4,104,105,40, '2023-07-01',25000000,503),
  (1005,5,104,102,50,'2023-08-25',25000000,508),
  (1006,2,108,107,50,'2023-01-20',50000,507),
  (1007,10,103,102,50,'2023-04-25',25000,501),
  (1008,8,104,105,50,'2022-10-02',24000000,504),
  (1009,9,106,102,50,'2023-03-27',45000000,506),
  (1010,7,109,107,50,'2023-08-25',26500000,505);
 
SELECT * FROM Transaction;

INSERT INTO Investor(Investor_ID,I_name, I_Contact_Info,I_address,Investment_focus,I_budget, Property_ID,Location_ID) 

 VALUES
  (2001,'Anima','01729463842','Banani,Dhaka','Residential',4500000,1,401),
  (2002,'Mehedi','017277773842','Tangail','Residential',5250000,1,401),
  (2003,'Ahmed','01375544842','Gazipur','Commercial',25000000,5,406),
  (2004,'Anondo','01976543842','Manikganj','Residential',20000000,3,405),
  (2005,'Habib','01798776542','Mirpur-2,Dhaka','Residential',25000000,4,403),
  (2006,'Walid','01798776542','Mouchak,Dhaka','Residential',4500000,8,410),
  (2007,'Neha','01203010230','Gabtoli,Dhaka','Commercial',15000000,5,406),
  (2008,'Atik','01478523698','Chittagong','Residential',45000000,4,403),
  (2009,'Nakiba','01420526320','Sylhet','Residential',45000000,3,405),
  (2010,'Safin','01925631487','Mirpur-10,Dhaka','Commercial',35000000,9,409),
  (2011,'Imran','01402053621','Mugda,Dhaka','Residential',20000000,8,410),
  (2012,'Emon','01741528632','Gabtoli,Dhaka','Residential',45000000,3,405);
 
SELECT * FROM Investor;

INSERT INTO Developer( Developer_ID, D_name, D_company_name,D_Contact_Info,D_address,D_rating, Property_ID,Location_ID) 

 VALUES
  (3001,'Rekha','AN company','01729463842','Banani,Dhaka',3.5,2,402),
  (3002,'Bobby','BN company','017277773842','Tangail',4,1,401),
  (3003,'Fuad','FS company','01375544842','Gazipur',3,5,404),
  (3004,'Ovi','FD company','01976543842','Uttora,Dhaka',3,3,400),
  (3005,'Ashik','EF company','01725968412','Gabtoli,Dhaka',4.5,7,405),
  (3006,'Reyad','HF company','01925331475','Gabtoli,Dhaka',3.5,2,401),
  (3007,'Taufiq','AL company','01702314856','Bonosre,Dhaka',4.2,3,403),
  (3008,'Zahid','ST company','01325416785','Kazipara,Dhaka',4.3,4,406),
  (3009,'Novera','SA company','01452639874','Gabtoli,Dhaka',4.1,8,409),
  (3010,'Hridi','NA company','01524246325','Agargaon,Dhaka',3.3,5,407);
 
SELECT * FROM Developer;

-- Update
Update Property
Set P_Price=40000000 Where Property_ID=3;
Update Property Set P_Price=20000000 Where Property_ID=4;
Update Property Set P_Price=47500000 Where Property_ID=5; 

SELECT * FROM Property;

-- Delete
Delete from Investor 
Where I_Name = 'Ahmed';
Delete from Investor
Where I_Contact_Info = '01478523698';

SELECT * FROM Investor;

-- Alter and Update
Alter Table Agent
Add A_salary decimal(8,2);
Update Agent
Set A_salary= Case
When Agency='TB Agency' then 20000
When A_Name='Mou' then 40000
When A_Name='Kamal' then 35000
When A_Contact_Info='+8801741528652' then 30000
Else A_salary
End;

SELECT * FROM Agent;
 
-- Drop
Alter table Location
Drop Zip;

SELECT * FROM Location;

-- Order by
select * from Customer
order by C_Name;

-- Group by
select count(Agent_Id)as total_agents,Agent_Id
from Agent
group by Agent_Id;

 -- Aggregate Function
select count(A_salary) from Agent;
select sum(A_salary) as total_salary from Agent;
select avg(A_salary) from Agent;
select max(A_salary) from Agent;
select min(A_salary) from Agent;
 
-- Subquery
-- select agent name where Property address is green road
select A_Name as 'Agent Name' from Agent
where Agent_ID in 
(select Agent_ID from Property
where P_Address='Green Road');
 
-- select available status where Feature_ID is 303
select P_Status from Property
where Property_ID in 
(select Property_ID from Property_Features
where Feature_ID=303);


-- Join operations
--  List all properties that are available for sale along with their agent details
SELECT p.P_Address, p.P_Price, p.P_Size, a.A_Name, a.A_Contact_Info
FROM Property p
JOIN Agent a ON p.Agent_ID = a.Agent_ID
WHERE p.P_Status = 'Sale';

-- Get the details of properties rented and rented by customers
SELECT p.P_Address, p.P_Size, p.P_Price, c.C_Name
FROM Property p
JOIN Transaction t ON p.Property_ID = t.Property_ID
JOIN Customer c ON t.Buyer_ID = c.Customer_ID
WHERE p.P_Status = 'rented';

-- List all the developers and their respective properties
SELECT d.D_name, d.D_company_name, p.P_Address
FROM Developer d
JOIN Property p ON d.Property_ID = p.Property_ID;

-- List all investors who have a budget above 10,000,000 and their investment focus
SELECT i.I_name, i.I_budget, i.Investment_focus
FROM Investor i
WHERE i.I_budget > 10000000;

-- Get all transactions for a specific agent (e.g., Agent with ID 20)
SELECT t.Transaction_ID, p.P_Address, t.T_Date, t.T_Price, c.C_Name AS Buyer_Name
FROM Transaction t
JOIN Property p ON t.Property_ID = p.Property_ID
JOIN Customer c ON t.Buyer_ID = c.Customer_ID
WHERE t.Agent_ID = 20;

-- Find properties that have specific features like "Garage" or "Pool"
SELECT p.P_Address, pf.Feature_Type, pf.Feature_Description
FROM Property_Features pf
JOIN Property p ON pf.Property_ID = p.Property_ID
WHERE pf.Feature_Type IN ('Garage', 'Pool');

-- Get the most expensive property sold along with its transaction details
SELECT p.P_Address, p.P_Price, t.T_Date, t.T_Price
FROM Property p
JOIN Transaction t ON p.Property_ID = t.Property_ID
WHERE p.P_Status = 'Sold'
ORDER BY t.T_Price DESC;

-- Find out the location with the highest number of properties listed
SELECT l.City, COUNT(p.Property_ID) AS total_properties
FROM Property p
JOIN Location l ON p.Location_ID = l.Location_ID
GROUP BY l.City
ORDER BY total_properties DESC;


-- List all properties sold along with the buyer's and seller's names
SELECT p.P_Address, t.T_Date, c1.C_Name AS Buyer_Name, c2.C_Name AS Seller_Name
FROM Property p
JOIN Transaction t ON p.Property_ID = t.Property_ID
JOIN Customer c1 ON t.Buyer_ID = c1.Customer_ID
JOIN Customer c2 ON t.Seller_ID = c2.Customer_ID
WHERE p.P_Status = 'Sold';

-- Get the total number of properties sold for each agent
SELECT a.A_Name, COUNT(t.Transaction_ID) AS properties_sold
FROM Agent a
JOIN Property p ON a.Agent_ID = p.Agent_ID
JOIN Transaction t ON p.Property_ID = t.Property_ID
WHERE t.Transaction_Type_ID = 504  -- Sold Transaction Type
GROUP BY a.A_Name;

-- all,some,exist,not exist
-- Find all properties that have a price greater than the price of all properties in the "Uttora" location

SELECT P_Address, P_Price
FROM Property
WHERE P_Price > ALL (SELECT P_Price
                    FROM Property
                    JOIN Location ON Property.Location_ID = Location.Location_ID
                    WHERE City = 'Uttora');

-- Find properties whose price is greater than the price of some properties in the "Mouchak" location
SELECT P_Address, P_Price
FROM Property
WHERE P_Price > SOME (SELECT P_Price
                      FROM Property
                      JOIN Location ON Property.Location_ID = Location.Location_ID
                      WHERE City = 'Mouchak');

-- Find agents who have at least one property sold

SELECT A_Name, A_Contact_Info
FROM Agent a
WHERE EXISTS (SELECT 1
              FROM Property p
              JOIN Transaction t ON p.Property_ID = t.Property_ID
              WHERE p.Agent_ID = a.Agent_ID AND t.Transaction_Type_ID = 504);  

-- Find properties that do not have a "Pool" feature
SELECT P_Address, P_Price
FROM Property p
WHERE NOT EXISTS (SELECT 1
                  FROM Property_Features pf
                  WHERE pf.Property_ID = p.Property_ID
                  AND pf.Feature_Type = 'Pool');

-- Find properties that have a specific feature (e.g., "Garage")
SELECT P_Address, P_Price
FROM Property p
WHERE EXISTS (SELECT 1
              FROM Property_Features pf
              WHERE pf.Property_ID = p.Property_ID
              AND pf.Feature_Type = 'Garage');

